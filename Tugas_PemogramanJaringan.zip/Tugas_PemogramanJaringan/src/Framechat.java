import javax.swing.*;

public class Framechat {
    private JPanel panel1;
    private JComboBox cbConnection;
    private JButton btnConnect;
    private JTextField TxtUser;
    private JList listmessage;
    private JTextField txtmessage;
    private JButton btnmessage;
}
